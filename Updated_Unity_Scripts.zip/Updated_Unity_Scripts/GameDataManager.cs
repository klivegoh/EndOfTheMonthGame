using System.Collections.Generic;
using UnityEngine;

public class GameDataManager : MonoBehaviour
{
    [Header("Resource Paths")]
    [SerializeField] private string settingsCSVPath = "Data/Settings";
    [SerializeField] private string categoriesCSVPath = "Data/Categories";
    [SerializeField] private string cardsCSVPath = "Data/Cards";
    [SerializeField] private string eventsCSVPath = "Data/Events";
    [SerializeField] private string streaksCSVPath = "Data/Streaks";
    [SerializeField] private string rewardsCSVPath = "Data/Rewards";

    public Dictionary<string, string> Settings { get; private set; } = new Dictionary<string, string>();
    public List<BudgetCategory> CategoryDefaults { get; private set; } = new List<BudgetCategory>();
    public List<DecisionCardData> AllCards { get; private set; } = new List<DecisionCardData>();
    public List<EventData> AllEvents { get; private set; } = new List<EventData>();
    public List<StreakData> AllStreaks { get; private set; } = new List<StreakData>();
    public List<RewardData> AllRewards { get; private set; } = new List<RewardData>();

    private void Awake()
    {
        LoadAllData();
    }

    private void LoadAllData()
    {
        LoadSettings();
        LoadCategories();
        LoadCards();
        LoadEvents();
        LoadStreaks();
        LoadRewards();
    }

    public int GetIntSetting(string key, int fallback)
    {
        if (!Settings.ContainsKey(key)) return fallback;

        int result;
        if (int.TryParse(Settings[key], out result)) return result;

        return fallback;
    }

    public string GetStringSetting(string key, string fallback)
    {
        return Settings.ContainsKey(key) ? Settings[key] : fallback;
    }

    private void LoadSettings()
    {
        TextAsset settingsCSV = Resources.Load<TextAsset>(settingsCSVPath);
        Settings.Clear();

        if (settingsCSV == null)
        {
            Debug.LogWarning("Settings CSV could not be loaded from Resources path: " + settingsCSVPath + ". Using Inspector defaults.");
            return;
        }

        List<string[]> rows = CSVReader.ReadCSV(settingsCSV.text);

        // Expected header: Key, Value, Type
        for (int i = 1; i < rows.Count; i++)
        {
            string[] row = rows[i];
            if (row.Length < 2) continue;

            string key = row[0].Trim();
            string value = row[1].Trim();

            if (!string.IsNullOrEmpty(key))
            {
                Settings[key] = value;
            }
        }

        Debug.Log("Loaded settings from CSV: " + Settings.Count);
    }

    private void LoadCategories()
    {
        TextAsset categoriesCSV = Resources.Load<TextAsset>(categoriesCSVPath);
        CategoryDefaults.Clear();

        if (categoriesCSV == null)
        {
            Debug.LogWarning("Categories CSV could not be loaded from Resources path: " + categoriesCSVPath + ". Using BudgetManager Inspector categories.");
            return;
        }

        List<string[]> rows = CSVReader.ReadCSV(categoriesCSV.text);

        // Expected header: CategoryID, DisplayName, DefaultBudgetAmount, IsEssential, ColorHex
        for (int i = 1; i < rows.Count; i++)
        {
            string[] row = rows[i];
            if (row.Length < 3)
            {
                Debug.LogWarning("Skipping invalid category row at index: " + i + " | Columns found: " + row.Length);
                continue;
            }

            BudgetCategory category = new BudgetCategory();
            category.category = ParseCategory(row[0]);
            category.allocatedAmount = ParseInt(row[2]);
            category.spentAmount = 0;

            CategoryDefaults.Add(category);
        }

        Debug.Log("Loaded category defaults from CSV: " + CategoryDefaults.Count);
    }

    private void LoadCards()
    {
        TextAsset cardsCSV = Resources.Load<TextAsset>(cardsCSVPath);

        if (cardsCSV == null)
        {
            Debug.LogError("Cards CSV could not be loaded from Resources path: " + cardsCSVPath);
            return;
        }

        List<string[]> rows = CSVReader.ReadCSV(cardsCSV.text);
        AllCards.Clear();

        // Expected header:
        // CardID, CardName, CategoryID, CardType, Cost, SavingsChange, Weight,
        // MinDay, MaxDay, IsActive, ShortText, FeedbackText, Consequence, ContextSG
        for (int i = 1; i < rows.Count; i++)
        {
            string[] row = rows[i];

            if (row.Length < 14)
            {
                Debug.LogWarning("Skipping invalid card row at index: " + i + " | Columns found: " + row.Length);
                continue;
            }

            bool isActive = ParseBool(row[9]);
            if (!isActive) continue;

            DecisionCardData card = new DecisionCardData(
                row[0].Trim(),
                row[1].Trim(),
                ParseCategory(row[2]),
                NormalizeCardType(row[3]),
                ParseInt(row[4]),
                ParseInt(row[5]),
                ParseInt(row[6]),
                ParseInt(row[7]),
                ParseInt(row[8]),
                isActive,
                row[10].Trim(),
                row[11].Trim(),
                row[12].Trim(),
                row[13].Trim()
            );

            AllCards.Add(card);
        }

        Debug.Log("Loaded cards from CSV: " + AllCards.Count);
    }

    private void LoadEvents()
    {
        TextAsset eventsCSV = Resources.Load<TextAsset>(eventsCSVPath);

        if (eventsCSV == null)
        {
            Debug.LogError("Events CSV could not be loaded from Resources path: " + eventsCSVPath);
            return;
        }

        List<string[]> rows = CSVReader.ReadCSV(eventsCSV.text);
        AllEvents.Clear();

        // Expected header:
        // EventID, EventName, TriggerCategory, CardType, DayRequirement, EventText, Weight
        for (int i = 1; i < rows.Count; i++)
        {
            string[] row = rows[i];

            if (row.Length < 7)
            {
                Debug.LogWarning("Skipping invalid event row at index: " + i + " | Columns found: " + row.Length);
                continue;
            }

            int minDay;
            int maxDay;
            ParseDayRequirement(row[4], out minDay, out maxDay);

            EventData eventData = new EventData(
                row[0].Trim(),
                row[1].Trim(),
                ParseCategory(row[2]),
                NormalizeCardType(row[3]),
                minDay,
                maxDay,
                row[5].Trim(),
                ParseInt(row[6])
            );

            AllEvents.Add(eventData);
        }

        Debug.Log("Loaded events from CSV: " + AllEvents.Count);
    }

    private void LoadStreaks()
    {
        TextAsset streaksCSV = Resources.Load<TextAsset>(streaksCSVPath);

        if (streaksCSV == null)
        {
            Debug.LogError("Streaks CSV could not be loaded from Resources path: " + streaksCSVPath);
            return;
        }

        List<string[]> rows = CSVReader.ReadCSV(streaksCSV.text);
        AllStreaks.Clear();

        // Expected header: StreakID, StreakName, StreakType, RewardPerDay, UnlockAfterDays, BonusMessage
        for (int i = 1; i < rows.Count; i++)
        {
            string[] row = rows[i];

            if (row.Length < 6)
            {
                Debug.LogWarning("Skipping invalid streak row at index: " + i + " | Columns found: " + row.Length);
                continue;
            }

            StreakData streakData = new StreakData(
                row[0].Trim(),
                row[1].Trim(),
                row[2].Trim(),
                ParseInt(row[3]),
                ParseInt(row[4]),
                row[5].Trim()
            );

            AllStreaks.Add(streakData);
        }

        Debug.Log("Loaded streaks from CSV: " + AllStreaks.Count);
    }

    private void LoadRewards()
    {
        TextAsset rewardsCSV = Resources.Load<TextAsset>(rewardsCSVPath);

        if (rewardsCSV == null)
        {
            Debug.LogError("Rewards CSV could not be loaded from Resources path: " + rewardsCSVPath);
            return;
        }

        List<string[]> rows = CSVReader.ReadCSV(rewardsCSV.text);
        AllRewards.Clear();

        // Expected header: RewardID, RewardName, TriggerCondition, RewardType, RewardValue, DisplayMessage
        for (int i = 1; i < rows.Count; i++)
        {
            string[] row = rows[i];

            if (row.Length < 6)
            {
                Debug.LogWarning("Skipping invalid reward row at index: " + i + " | Columns found: " + row.Length);
                continue;
            }

            RewardData rewardData = new RewardData(
                row[0].Trim(),
                row[1].Trim(),
                row[2].Trim(),
                row[3].Trim(),
                ParseInt(row[4]),
                row[5].Trim()
            );

            AllRewards.Add(rewardData);
        }

        Debug.Log("Loaded rewards from CSV: " + AllRewards.Count);
    }

    private void ParseDayRequirement(string value, out int minDay, out int maxDay)
    {
        minDay = 1;
        maxDay = GetIntSetting("RunLengthDays", 7);

        if (string.IsNullOrWhiteSpace(value)) return;

        value = value.Trim();

        if (value.Contains("-"))
        {
            string[] parts = value.Split('-');

            if (parts.Length == 2)
            {
                minDay = ParseInt(parts[0]);
                maxDay = ParseInt(parts[1]);
            }
        }
        else
        {
            int singleDay = ParseInt(value);
            minDay = singleDay;
            maxDay = singleDay;
        }
    }

    private CategoryType ParseCategory(string value)
    {
        switch (value.Trim().ToUpper())
        {
            case "FOOD":
                return CategoryType.Food;

            case "TRANSPORT":
            case "TRAN":
                return CategoryType.Transport;

            case "LEISURE":
                return CategoryType.Leisure;

            case "SAVINGS":
                return CategoryType.Savings;

            case "INCOME":
                return CategoryType.Income;

            default:
                Debug.LogWarning("Unknown category: " + value + ". Defaulting to Food.");
                return CategoryType.Food;
        }
    }

    private string NormalizeCardType(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return "Generic";
        return value.Trim();
    }

    private int ParseInt(string value)
    {
        int result;
        int.TryParse(value.Trim(), out result);
        return result;
    }

    private bool ParseBool(string value)
    {
        string clean = value.Trim().ToLower();
        return clean == "true" || clean == "1" || clean == "yes";
    }
}

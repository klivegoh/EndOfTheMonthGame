using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class DecisionCardUI : MonoBehaviour
{
    [SerializeField] private TMP_Text nameText;
    [SerializeField] private TMP_Text costText;
    [SerializeField] private TMP_Text descriptionText;
    [SerializeField] private Button button;

    private DecisionCardData cardData;
    private GameplayManager gameplayManager;

    public void Setup(DecisionCardData data, GameplayManager manager)
    {
        cardData = data;
        gameplayManager = manager;

        nameText.text = data.cardName;
        descriptionText.text = BuildDescription(data);

        if (data.cost < 0)
        {
            costText.text = "+$" + Mathf.Abs(data.cost);
        }
        else if (data.cost == 0)
        {
            costText.text = "$0";
        }
        else
        {
            costText.text = "-$" + data.cost;
        }

        button.onClick.RemoveAllListeners();
        button.onClick.AddListener(OnClicked);
    }

    private string BuildDescription(DecisionCardData data)
    {
        string result = data.description;

        if (!string.IsNullOrWhiteSpace(data.consequence))
        {
            result += "\n" + data.consequence;
        }

        if (!string.IsNullOrWhiteSpace(data.contextSG))
        {
            result += "\nSG: " + data.contextSG;
        }

        return result;
    }

    private void OnClicked()
    {
        gameplayManager.PlayCard(cardData);
    }
}

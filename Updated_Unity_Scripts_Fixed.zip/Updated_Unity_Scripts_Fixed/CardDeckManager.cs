using System.Collections.Generic;
using UnityEngine;

public class CardDeckManager : MonoBehaviour
{
    [SerializeField] private GameDataManager gameDataManager;

    public List<DecisionCardData> DrawCards(int amount, int currentDay, CategoryType category, string requiredCardType)
    {
        List<DecisionCardData> exactMatches = new List<DecisionCardData>();
        List<DecisionCardData> genericFallbacks = new List<DecisionCardData>();
        List<DecisionCardData> sameCategoryBackups = new List<DecisionCardData>();

        string fallbackType = gameDataManager.GetStringSetting("FallbackCardType", "Generic");

        foreach (DecisionCardData card in gameDataManager.AllCards)
        {
            if (!card.isActive) continue;
            if (currentDay < card.minDay || currentDay > card.maxDay) continue;
            if (card.category != category) continue;

            if (card.cardType == requiredCardType)
            {
                exactMatches.Add(card);
            }
            else if (card.cardType == fallbackType)
            {
                genericFallbacks.Add(card);
            }
            else
            {
                sameCategoryBackups.Add(card);
            }
        }

        List<DecisionCardData> drawnCards = new List<DecisionCardData>();

        DrawWeightedCardsIntoList(exactMatches, drawnCards, amount);

        if (drawnCards.Count < amount)
        {
            DrawWeightedCardsIntoList(genericFallbacks, drawnCards, amount - drawnCards.Count);
        }

        // Final safety net: if the CSV data is incomplete, still fill the hand
        // from same-category cards rather than showing only one or two buttons.
        if (drawnCards.Count < amount)
        {
            DrawWeightedCardsIntoList(sameCategoryBackups, drawnCards, amount - drawnCards.Count);
        }

        if (drawnCards.Count < amount)
        {
            Debug.LogWarning(
                "Only drew " + drawnCards.Count + " card(s) for " + category +
                " / " + requiredCardType + ". Add more exact or Generic cards to the CSV."
            );
        }

        return drawnCards;
    }

    private void DrawWeightedCardsIntoList(List<DecisionCardData> sourceCards, List<DecisionCardData> outputCards, int amount)
    {
        for (int i = 0; i < amount; i++)
        {
            if (sourceCards.Count == 0) break;

            DecisionCardData selectedCard = GetWeightedRandomCard(sourceCards);
            outputCards.Add(selectedCard);
            sourceCards.Remove(selectedCard);
        }
    }

    private DecisionCardData GetWeightedRandomCard(List<DecisionCardData> cards)
    {
        int totalWeight = 0;

        foreach (DecisionCardData card in cards)
        {
            totalWeight += Mathf.Max(0, card.weight);
        }

        if (totalWeight <= 0)
        {
            return cards[Random.Range(0, cards.Count)];
        }

        int randomValue = Random.Range(0, totalWeight);
        int runningTotal = 0;

        foreach (DecisionCardData card in cards)
        {
            runningTotal += Mathf.Max(0, card.weight);

            if (randomValue < runningTotal)
            {
                return card;
            }
        }

        return cards[0];
    }
}

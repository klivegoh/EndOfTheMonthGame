using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class DecisionCardUI : MonoBehaviour
{
    [SerializeField] private TMP_Text nameText;
    [SerializeField] private TMP_Text costText;
    [SerializeField] private TMP_Text descriptionText;
    [SerializeField] private Button button;

    private DecisionCardData cardData;
    private GameplayManager gameplayManager;

    public void Setup(DecisionCardData data, GameplayManager manager)
    {
        cardData = data;
        gameplayManager = manager;

        nameText.text = data.cardName;

        // Keep the card body simple for the demo.
        // Consequence and ContextSG remain in the CSV for future use,
        // but they are not displayed on the current card UI.
        descriptionText.text = data.description;

        if (data.cost < 0)
        {
            costText.text = "+$" + Mathf.Abs(data.cost);
        }
        else if (data.cost == 0)
        {
            costText.text = "$0";
        }
        else
        {
            costText.text = "-$" + data.cost;
        }

        button.onClick.RemoveAllListeners();
        button.onClick.AddListener(OnClicked);
    }

    private void OnClicked()
    {
        gameplayManager.PlayCard(cardData);
    }
}

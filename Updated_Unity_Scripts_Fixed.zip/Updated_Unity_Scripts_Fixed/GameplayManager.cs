using System.Collections.Generic;
using UnityEngine;

public class GameplayManager : MonoBehaviour
{
    [Header("Managers")]
    [SerializeField] private GameDataManager gameDataManager;
    [SerializeField] private BudgetManager budgetManager;
    [SerializeField] private CardDeckManager deckManager;
    [SerializeField] private UIManager uiManager;

    [Header("Extra Managers")]
    [SerializeField] private EventManager eventManager;
    [SerializeField] private StreakManager streakManager;
    [SerializeField] private RewardManager rewardManager;

    [Header("Card UI")]
    [SerializeField] private List<DecisionCardUI> cardSlots;

    [Header("Game Settings")]
    [SerializeField] private int maxDays = 7;
    [SerializeField] private int cardsPerDay = 3;

    private int currentDay = 1;
    private bool hasStarted = false;
    private EventData currentEvent;

    public void BeginRun()
    {
        if (hasStarted) return;

        hasStarted = true;
        currentDay = 1;

        if (gameDataManager != null)
        {
            maxDays = gameDataManager.GetIntSetting("RunLengthDays", maxDays);
            cardsPerDay = gameDataManager.GetIntSetting("CardsPerDay", cardsPerDay);
        }

        if (budgetManager != null && gameDataManager != null)
        {
            budgetManager.ApplyDataDefaults(gameDataManager);
        }

        uiManager.UpdateAllUI();
        StartDay();
    }

    public void StartDay()
    {
        uiManager.HideRewardPopup();
        uiManager.UpdateDayText(currentDay, maxDays);

        currentEvent = eventManager.GetRandomEventForDay(currentDay);

        if (currentEvent == null)
        {
            uiManager.ShowEventPrompt("No event found for today.");
            uiManager.ShowFeedback("Check your Events CSV day ranges.");
            HideAllCards();
            return;
        }

        uiManager.ShowEventPrompt(currentEvent.eventText);

        List<DecisionCardData> drawnCards = deckManager.DrawCards(
            cardsPerDay,
            currentDay,
            currentEvent.category,
            currentEvent.cardType
        );

        if (drawnCards.Count == 0)
        {
            uiManager.ShowFeedback("No cards found for " + currentEvent.category + " / " + currentEvent.cardType);
            HideAllCards();
            return;
        }

        for (int i = 0; i < cardSlots.Count; i++)
        {
            if (i < drawnCards.Count)
            {
                cardSlots[i].gameObject.SetActive(true);
                cardSlots[i].Setup(drawnCards[i], this);
            }
            else
            {
                cardSlots[i].gameObject.SetActive(false);
            }
        }
    }

    public void PlayCard(DecisionCardData card)
    {
        budgetManager.ApplyCard(card);

        if (streakManager != null)
        {
            streakManager.CheckStreaks(card);
            uiManager.UpdateStreakText(streakManager.GetMainStreakDisplay());
        }

        if (rewardManager != null)
        {
            List<RewardData> unlockedRewards = rewardManager.CheckRewards();

            if (unlockedRewards.Count > 0)
            {
                uiManager.ShowRewardPopup(unlockedRewards[0].displayMessage);
            }
        }

        uiManager.UpdateAllUI();
        uiManager.ShowFeedback(card.feedbackText);

        currentDay++;

        if (currentDay > maxDays)
        {
            EndRun();
        }
        else
        {
            StartDay();
        }
    }

    private void EndRun()
    {
        HideAllCards();
        uiManager.ShowEndSummary();
    }

    private void HideAllCards()
    {
        foreach (DecisionCardUI cardSlot in cardSlots)
        {
            cardSlot.gameObject.SetActive(false);
        }
    }
}

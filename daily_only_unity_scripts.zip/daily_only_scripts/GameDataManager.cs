using System.Collections.Generic;
using UnityEngine;

public class GameDataManager : MonoBehaviour
{
    [Header("Resource Paths")]
    [SerializeField] private string dailyEventPlanCSVPath = "Data/DailyEventPlan";

    public List<DailyEventPlanData> AllDailyPlans { get; private set; } = new List<DailyEventPlanData>();

    private void Awake()
    {
        LoadDailyEventPlan();
    }

    private void LoadDailyEventPlan()
    {
        TextAsset dailyCSV = Resources.Load<TextAsset>(dailyEventPlanCSVPath);

        if (dailyCSV == null)
        {
            Debug.LogError("DailyEventPlan CSV could not be loaded from Resources path: " + dailyEventPlanCSVPath);
            return;
        }

        List<string[]> rows = CSVReader.ReadCSV(dailyCSV.text);
        AllDailyPlans.Clear();

        // Expected header:
        // Day, DayName, ScenarioName, ScenarioText,
        // Choice1Name, Choice1Category, Choice1Cost, Choice1Feedback,
        // Choice2Name, Choice2Category, Choice2Cost, Choice2Feedback,
        // Choice3Name, Choice3Category, Choice3Cost, Choice3Feedback,
        // DesignPurpose
        for (int i = 1; i < rows.Count; i++)
        {
            string[] row = rows[i];

            if (row.Length < 17)
            {
                Debug.LogWarning("Skipping invalid daily plan row at index: " + i + " | Columns found: " + row.Length);
                continue;
            }

            int day = ParseInt(row[0]);
            string dayName = row[1];
            string scenarioName = row[2];
            string scenarioText = row[3];

            List<DailyChoiceData> choices = new List<DailyChoiceData>
            {
                new DailyChoiceData(row[4], ParseCategory(row[5]), ParseInt(row[6]), row[7]),
                new DailyChoiceData(row[8], ParseCategory(row[9]), ParseInt(row[10]), row[11]),
                new DailyChoiceData(row[12], ParseCategory(row[13]), ParseInt(row[14]), row[15])
            };

            string designPurpose = row[16];

            DailyEventPlanData plan = new DailyEventPlanData(
                day,
                dayName,
                scenarioName,
                scenarioText,
                choices,
                designPurpose
            );

            AllDailyPlans.Add(plan);
        }

        Debug.Log("Loaded daily event plans from CSV: " + AllDailyPlans.Count);
    }

    public DailyEventPlanData GetPlanForDay(int day)
    {
        return AllDailyPlans.Find(plan => plan.day == day);
    }

    private CategoryType ParseCategory(string value)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            Debug.LogWarning("Empty category found. Defaulting to Food.");
            return CategoryType.Food;
        }

        switch (value.Trim().ToUpper())
        {
            case "FOOD":
                return CategoryType.Food;

            case "TRANSPORT":
                return CategoryType.Transport;

            case "LEISURE":
                return CategoryType.Leisure;

            case "SAVINGS":
                return CategoryType.Savings;

            case "INCOME":
                return CategoryType.Income;

            default:
                Debug.LogWarning("Unknown category: " + value + ". Defaulting to Food.");
                return CategoryType.Food;
        }
    }

    private int ParseInt(string value)
    {
        int result;
        int.TryParse(value, out result);
        return result;
    }
}
